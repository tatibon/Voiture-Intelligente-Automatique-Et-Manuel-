 //PARAMETRRE DU MOTEUR
          #define  MoteurG2 13 // in1 pour faire tourne la roue gauche ver l'arrier
          #define  MoteurG1 12 // in2 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD1 10 // in3 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD2 9  // in4 pour faire tourne la roue gauche ver l'arrier 
          #define  PWMG 11 // ENA pour le sens du moteur gauche 
          #define  PWMD 8  // ENb pour le sens du moteur droit 

void setup() {
  // put your setup code here, to run once:
 pinMode(MoteurG1,OUTPUT);
            pinMode(MoteurG2,OUTPUT);
            pinMode(MoteurD1,OUTPUT);
            pinMode(MoteurD2,OUTPUT);
            pinMode( PWMG,OUTPUT);
            pinMode(PWMD,OUTPUT);
          

}

void loop() {
  // put your main code here, to run repeatedly:
    
digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,HIGH);//
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,HIGH);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100);
 }
