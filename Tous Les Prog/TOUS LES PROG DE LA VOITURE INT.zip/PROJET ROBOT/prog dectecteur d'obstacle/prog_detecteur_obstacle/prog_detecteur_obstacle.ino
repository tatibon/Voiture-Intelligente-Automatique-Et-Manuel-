        #include <Servo.h>// pour le cmmande du cerveau moteur
        // paramettre cerveau moteur
        int pinservo=7;
        Servo cerv;
        // paramettre ultra son
        #define trig 4
        #define echo 5
        long temps;
        long distance;
         //buzzer parametrage
         #define buzzer 6 //buzzer to arduino pin 3
       //PARAMETRRE DU MOTEUR
          #define  MoteurG2 13 // in1 pour faire tourne la roue gauche ver l'arrier
          #define  MoteurG1 12 // in2 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD1 10 // in3 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD2 9  // in4 pour faire tourne la roue gauche ver l'arrier 
          #define  pinENA 11 // ENA pour le sens du moteur gauche 
          #define  pinENB 8  // ENb pour le sens du moteur droit 

        // paramettre interupteur
          
        
          // partie déclarative des fonction utliser dans le programme
             long Mesure_distance();
             void servoMoteur(int angle);
             void fonction_rotation_cerveau();
             long Mesure();
             void fonction_gauche();
             void fonction_Droite();
             void fonction_arriere();
             void fonction_avance();
             void fonction_stop();
             void fonction_automatique(); 
         
void setup() {
          Serial.begin(9600);
          // initialisation des paramettres du cerveau moteur
          cerv.attach(pinservo); //définir le pin de commande du cerveau moteur
          cerv.write(58);
          // initialisation des paramettre de l'utra son
          pinMode(trig,OUTPUT);
          pinMode(echo,INPUT);
          digitalWrite(trig,LOW);
         //PARAMETRE DE INTERUPTEUR

           // put your setup code here, to run once:
pinMode(MoteurG1,OUTPUT);
pinMode(MoteurG2,OUTPUT);
pinMode(MoteurD1,OUTPUT);
pinMode(MoteurD2,OUTPUT);
pinMode( pinENA,OUTPUT);
pinMode(pinENB,OUTPUT);
          
          
          pinMode(buzzer, OUTPUT); // Set buzzer - pin 3 as an output

        }
        
void loop() {
    
      fonction_automatique();       

              
        }
         // fonction permetant de recuperé la distance messurer par le capteur ultra son
        long Mesure_distance(){
        long   temps=0;
          long distance=0;
          digitalWrite(trig,HIGH);
          delayMicroseconds(10);
          digitalWrite(trig,LOW);
          temps=pulseIn(echo,HIGH);// pour calculer le temps d'emissin du son et reception du son par le capteur utra son
          distance=temps/58; //pour calculer la distance mesurer en cm
          Serial.print("distance: "); 
          Serial.println(distance);

          delay(100);
         return(distance);
         }
         
         
         // fonction permettant de faire tourne le cerveau moteur d'un angle donné
         void servoMoteur(int angle) {
           
    cerv.write(angle); //pour faire tourne le cerveau moteur d'un angle angle
    }
    
   void fonction_rotation_cerveau(){ // fonction qui premet au robot d'interagir avec son environnement
        long a=0;// a n'est pas une variable 
       tone(buzzer,650,10000); // Send 1KHz sound signal...
        //  rotation a droite du capteur ultra-son et fonction a executer
       
          servoMoteur(30);// on effectue une rotation a droite
              
                    delay(500);// pour une pause
      
                     a=Mesure();// on effectue 5 prise pour avoir une bonne mesure
         
                if(a>50){// dans le cas ou il y a pas de choc
                    noTone(buzzer);    // buzzer stop
                    fonction_Droite();//le robot tourne a droite
                    delay(600);//on attend 
                    fonction_stop();//le robot s'arrete
                    delay(500);//on attend
                    servoMoteur(88);// pour placer le capteur le capteur ultra son a la position avance
                    delay(500);// on atteend
                    
                            while(a>50){  //tant que la distance est superieur a 50 alors
                                 noTone(buzzer);// le buzzer s'arrete      
                                fonction_avance();// on avance
                               a=Mesure();// pour evite de tourné indéfinement dans la boucle 
                               
                                }
                                 
                                 fonction_stop();// le robot s'arrete
                         delay(500);// on attend
                                }
                                 tone(buzzer,650,10000); // le buzzer emet une alerte
            servoMoteur(88);// on place le capteur ultra son au centre     
            
     delay(500);// on attend
        servoMoteur(150);// on tourne le capteur ultra son a gauche pour mesure la distance
      delay(500);// on attend
                          
                     
               // on effectue une rotation a gauche car la mesure est inférieur au seuil alors on deplace le capteur ultra son de la droite vers la gauche             
                         
                          // test de l'etat gauche apres une rotation
              
                     a=Mesure();// on effectue 5 prise pour avoir une bonne mesure
                if(a>50){ // dans le cas ou il y a pas d'obstacle a gauche
                    noTone(buzzer);    // Stop sound...
                    fonction_gauche();// le robot tourne a gauche
                   delay(600);// on attend
                    fonction_stop();// le robot s'arrete
                           delay(300);// on attend
                    servoMoteur(88);// centriliser le capteur ultra song avant d'avance
                    delay(300);// on attend
    
                            while(a>40){
                                  noTone(buzzer);    // on stop le son du buzzer     
                                fonction_avance();//on avance tant que a>40
                                 // pour evite de caller dans la boucle 
                                 a=Mesure();
                                }
                                
                                fonction_stop();
                                delay(500); 
                            }
                           if(a<45){
                                   fonction_stop();// on stop le robot 
                                  delay(400);// on attend 
                           fonction_arriere();//on rentre
                           delay(500);//pendant 400 milies seconde
                            fonction_stop();// on stop le robot
                          delay(500);// on attend 
                         
                            } 
                            
                              a=Mesure();// on remesure la distance
                        }
                        
                        
                        
          long Mesure(){// pour faire 1 mesure avant de prendre une décission.modifiable si necssaire
             int i;
             long a=0;
           
               for(i=0;i<=1 ;i++){
                    a= Mesure_distance();
                      i++;
                  }
                  return(a);
                  }
  void fonction_gauche()
{
  // le premier moteur tourne en marche avant, lentement
  analogWrite(pinENA, 0); // vitesse lente (entre 0 et 255)
  digitalWrite(MoteurG2, false);
  digitalWrite(MoteurG1, false);
  analogWrite(pinENB,215); // vitesse assez rapide
  digitalWrite(MoteurD1, true);
  digitalWrite(MoteurD2, false);
}
void fonction_Droite()
{    
  analogWrite(pinENA, 215); // vitesse lente (entre 0 et 255)
  digitalWrite(MoteurG2, true);
  digitalWrite(MoteurG1, false);
  analogWrite(pinENB, 0); // vitesse assez rapide
  digitalWrite(MoteurD1, false);
  digitalWrite(MoteurD2, false);
}
void fonction_arriere()
{

  analogWrite(pinENA, 130);
  digitalWrite(MoteurG2,false);
  digitalWrite(MoteurG1,true);

  analogWrite(pinENB, 130); // vitesse assez rapide
  digitalWrite(MoteurD1, false);
  digitalWrite(MoteurD2, true);
 

}
void fonction_avance()
{
 
  analogWrite(pinENA, 130);
  digitalWrite(MoteurG2,true);
  digitalWrite(MoteurG1,false);

  analogWrite(pinENB, 130); // vitesse assez rapide
  digitalWrite(MoteurD1, true);
  digitalWrite(MoteurD2, false);
}
void fonction_stop()  
{

  analogWrite(pinENA, 0);
  digitalWrite(MoteurG2,false);
  digitalWrite(MoteurG1,false);

  analogWrite(pinENB, 0); // vitesse assez rapide
  digitalWrite(MoteurD1, false);
  digitalWrite(MoteurD2, false);
}
     void fonction_automatique(){// mode automatique 
          
                          long distance=0;// variable qui va contenir la distance
          
            distance=Mesure_distance();// on recupere la valeur mesure apres cinp opérations pour une bonne prise de
            // de décision
            if(distance>40){// si la distance est superieur a 40 alors
            while(distance>40){//tant que la ditance est superieur a 40 alors
                         fonction_avance(); // on avance
                      distance=Mesure(); //on fait des mesures pour eviter de tourner idéfinement dans la boucle
                      }
            }
                         fonction_stop();
             delay(500);
            fonction_arriere();
            delay(500);
            fonction_stop();
             delay(300);
         fonction_rotation_cerveau();
    }
 }                        
