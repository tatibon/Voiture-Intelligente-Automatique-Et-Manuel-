        #include <Servo.h>// pour le cmmande du cerveau moteur
        // paramettre cerveau moteur
        int pinservo=7;
        Servo cerv;
        // paramettre ultra son
        #define trig 6
        #define echo 5
        long temps;
        long distance;
        // paramettre led
        int led=2;
        //PARAMETRRE DU MOTEUR
          #define  MoteurG2 13 // in1 pour faire tourne la roue gauche ver l'arrier
          #define  MoteurG1 12 // in2 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD1 10 // in3 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD2 9  // in4 pour faire tourne la roue gauche ver l'arrier 
          #define  PWMG 11 // ENA pour le sens du moteur gauche 
          #define  PWMD 8  // ENb pour le sens du moteur droit 

     
          // partie déclarative des fonction utliser dans le programme
             long Mesure_distance();
             void servoMoteur(int angle);
             void fonction_rotation_cerveau();
             long Mesure();
             void fonction_gauche();
             void fonction_Droite();
             void fonction_arriere();
             void fonction_avance();
             void fonction_stop();
            
         
        void setup() {
          Serial.begin(9600);
          // initialisation des paramettres du cerveau moteur
          cerv.attach(pinservo); //définir le pin de commande du cerveau moteur
          // initialisation des paramettre de l'utra son
          pinMode(trig,OUTPUT);
          pinMode(echo,INPUT);
          digitalWrite(trig,LOW);
          // initialisation paramettres led
          pinMode(led,OUTPUT);
          digitalWrite(led,LOW);
         
        }
        
        void loop() {
    
         fonction_rotation_cerveau();
        
        }
         // fonction permetant de recuperé la distance messurer par le capteur ultra son
        long Mesure_distance(){
        long   temps=0;
          long distance=0;
          digitalWrite(trig,HIGH);
          delayMicroseconds(10);
          digitalWrite(trig,LOW);
          temps=pulseIn(echo,HIGH);// pour calculer le temps d'emissin du son et reception du son par le capteur utra son
          distance=temps/58; //pour calculer la distance mesurer en cm
          Serial.print("distance: "); 
          Serial.println(distance);

          delay(1000);
         return(distance);
         }
         
         
         // fonction permettant de faire tourne le cerveau moteur d'un angle donné
         void servoMoteur(int angle) {
           
    cerv.write(angle); //pour faire tourne le cerveau moteur d'un angle angle
    }
    
     void fonction_rotation_cerveau(){
        long a=0;// a n'est pas une variable 
       
        //  rotation a droite du capteur ultra-son et fonction a executer
       
          servoMoteur(7);// on effectue une rotation a droite
              
                    delay(100);// pour une pause
      
                     a=Mesure();// on effectue 5 prise pour avoir une bonne mesure
         
                if(a>30){// dans le cas ou il y a pas de choc
                     
          
                   delay(88);
                    servoMoteur(58);// pour placer le capteur le capteur ultra son a la position avance
                    delay(500);
                    
                            while(a>30){
                                      
                               
                                 // pour evite de tourné indéfinement dans la boucle 
                                 a=Mesure();
                                }
                         delay(500);
                                }
            servoMoteur(58);     
            
            delay(100);
              servoMoteur(113);
       
               // on effectue une rotation a gauche car la mesure est inférieur au seuil alors on deplace le capteur ultra son de la droite vers la gauche             
                          
                          // test de l'etat gauche apres une rotation
              
                     a=Mesure();// on effectue 5 prise pour avoir une bonne mesure
                if(a>30){ // dans le cas ou il y a pas d'obstacle a gauche
                   
             
                   delay(88);
                    servoMoteur(58);// centriliser le capteur ultra song avant d'avance
                    delay(100);
               
                            while(a>30){
                                      
                               
                                 // pour evite de caller dans la boucle 
                                 a=Mesure();
                                }
                   
                            }
                           
                        }
                        
                        
                        
          long Mesure(){// pour faire 5 mesure avant de prendre une décission
             int i;
             long a=0;
           
               for(i=0;i<=5;i++){
                    a= Mesure_distance();
                      i++;
                  }
                  return(a);
                  }
