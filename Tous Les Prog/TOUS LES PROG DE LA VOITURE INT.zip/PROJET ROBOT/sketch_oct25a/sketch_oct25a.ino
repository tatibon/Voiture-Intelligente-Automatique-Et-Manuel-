#include <Servo.h> // appel de la bibliotheque du servo moteur
Servo Direction; // on attribut le nom de "direction" au servo moteur
 // paramettre ultra son
        #define trig 4
        #define echo 5
        long temps;
        long distance;
        
          // partie déclarative des fonction utliser dans le programme
             long Mesure_distance();
             void servoMoteur(int angle);
             void fonction_rotation_cerveau();
             long Mesure();
             void fonction_gauche();
             void fonction_Droite();
             void fonction_arriere();
             void fonction_avance();
             void fonction_stop();
             float pas;
             void bluetooth();
             
char t; // on declare une variable "t' de type char
  #define  MoteurG2 13 // in1 pour faire tourne la roue gauche ver l'arrier
          #define  MoteurG1 12 // in2 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD1 10 // in3 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD2 9  // in4 pour faire tourne la roue gauche ver l'arrier 
          #define  PWMG 11 // ENA pour le sens du moteur gauche 
          #define  PWMD 8  // ENb pour le sens du moteur droit 

void setup() {
pinMode(MoteurG1,OUTPUT);
            pinMode(MoteurG2,OUTPUT);
            pinMode(MoteurD1,OUTPUT);
            pinMode(MoteurD2,OUTPUT);
            pinMode( PWMG,OUTPUT);
            pinMode(PWMD,OUTPUT);
           // configuration du sens d'utilisation des
Serial.begin(9600);
Direction.attach(5);

 // initialisation des paramettre de l'utra son
          pinMode(trig,OUTPUT);
          pinMode(echo,INPUT);
          digitalWrite(trig,LOW);
}
void loop() {
 bluetooth();
  Mesure_distance();
}
 // fonction permetant de recuperé la distance messurer par le capteur ultra son
        long Mesure_distance(){
        long   temps=0;
          long distance=0;
          digitalWrite(trig,HIGH);
          delayMicroseconds(10);
          digitalWrite(trig,LOW);
          temps=pulseIn(echo,HIGH);// pour calculer le temps d'emissin du son et reception du son par le capteur utra son
          distance=temps/58; //pour calculer la distance mesurer en cm
          Serial.print("distance: "); 
          Serial.println(distance);

          delay(100);
         return(distance);
         }
         
 void bluetooth(){
if(Serial.available()){ // on initialise la communication serie avec
 a= Mesure_distance();
 t = Serial.read(); // a la variable t on affecte le signal

}
if(t == 'A'){
  Serial.print(t);
  while(a>30)
    {
digitalWrite(MoteurD2,HIGH);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,HIGH);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100); //si aucun signal n'est recut les

    }
}
if(t == 'E'){
 
digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,HIGH);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,HIGH);
digitalWrite(PWMG,100);
 Serial.print(t);
}
if(t == 'D'){
   
digitalWrite(MoteurD2,HIGH);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100); // si t vaut 'B' le relais 2 eteint, le
Serial.print(t);
}
if(t == 'G'){
 digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,HIGH);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100);
 Serial.print(t);
}
if(t == 'G'){
    
digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100);
 Serial.print(t);
}
}
