#include <Servo.h> // appel de la bibliotheque du servo moteur
Servo Direction; // on attribut le nom de "direction" au servo moteur
char t; // on declare une variable "t' de type char
  #define  MoteurG2 13 // in1 pour faire tourne la roue gauche ver l'arrier
          #define  MoteurG1 12 // in2 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD1 10 // in3 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD2 9  // in4 pour faire tourne la roue gauche ver l'arrier 
          #define  PWMG 11 // ENA pour le sens du moteur gauche 
          #define  PWMD 8  // ENb pour le sens du moteur droit 
float pas;
void setup() {
pinMode(MoteurG1,OUTPUT);
            pinMode(MoteurG2,OUTPUT);
            pinMode(MoteurD1,OUTPUT);
            pinMode(MoteurD2,OUTPUT);
            pinMode( PWMG,OUTPUT);
            pinMode(PWMD,OUTPUT);
           // configuration du sens d'utilisation des
Serial.begin(9600);
Direction.attach(5);
}
void loop() {
 // put your main code here, to run repeatedly:2I
if(Serial.available()){ // on initialise la communication serie avec

 t = Serial.read(); // a la variable t on affecte le signal

}
if(t == 'A'){
    
digitalWrite(MoteurD2,HIGH);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,HIGH);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100); //si aucun signal n'est recut les
Serial.print(t);
}
if(t == 'B'){
 
digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,HIGH);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,HIGH);
digitalWrite(PWMG,100);
 Serial.print(t);
}
if(t == 'C'){
   
digitalWrite(MoteurD2,HIGH);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100); // si t vaut 'B' le relais 2 eteint, le
Serial.print(t);
}
if(t == 'D'){
 digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,HIGH);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100);
 Serial.print(t);
}
if(t == 'E'){
    
digitalWrite(MoteurD2,LOW);

digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100);
 Serial.print(t);
}
if(t == ""){
Serial.println("arol");
}
}
