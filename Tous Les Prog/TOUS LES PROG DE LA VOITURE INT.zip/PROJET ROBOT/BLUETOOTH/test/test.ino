        #include <Servo.h>// pour le cmmande du cerveau moteur
        // paramettre cerveau moteur
        int pinservo=7;
        Servo cerv;
        // paramettre ultra son
        #define trig 4
        #define echo 5
        long temps;
        long distance;
        //PARAMETRRE DU MOTEUR
          #define  MoteurG2 13 // in1 pour faire tourne la roue gauche ver l'arrier
          #define  MoteurG1 12 // in2 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD1 10 // in3 pour faire tourne la roue gauche ver l'arrier 
          #define  MoteurD2 9  // in4 pour faire tourne la roue gauche ver l'arrier 
          #define  PWMG 11 // ENA pour le sens du moteur gauche 
          #define  PWMD 8  // ENb pour le sens du moteur droit 
        //Parametre de l'interrupteur
     

        //buzzer parametrage
         #define buzzer 6 //buzzer to arduino pin 3
        // parametre BLUETOOTH
          #include <SoftwareSerial.h>

SoftwareSerial hc06(2,3);//TX et RX

String cmd="";
float sensor_val=0;
        // partie déclarative des fonction utliser dans le programme
             long Mesure_distance();
             void servoMoteur(int angle);
             void fonction_rotation_cerveau();
             long Mesure();
             void fonction_gauche();
             void fonction_Droite();
             void fonction_arriere();
             void fonction_avance();
             void fonction_stop();
    
           void fonction_automatique(); 
         
void setup() {
          Serial.begin(9600);
          // initialisation des paramettres du cerveau moteur
          cerv.attach(pinservo); //définir le pin de commande du cerveau moteur
          cerv.write(58);
          
          // initialisation des paramettre de l'utra son
          pinMode(trig,OUTPUT);
          pinMode(echo,INPUT);
          digitalWrite(trig,LOW);
          //initialisation du buzzer
          pinMode(buzzer, OUTPUT); // Set buzzer - pin 6 as an output

          //Initialize Bluetooth Serial Port
  hc06.begin(9600);
          //PARAMETRE DES ROUES
            pinMode(MoteurG1,OUTPUT);
            pinMode(MoteurG2,OUTPUT);
            pinMode(MoteurD1,OUTPUT);
            pinMode(MoteurD2,OUTPUT);
            pinMode( PWMG,OUTPUT);
            pinMode(PWMD,OUTPUT);
           digitalWrite(MoteurD1,LOW);
            digitalWrite(PWMD,LOW);
            digitalWrite(MoteurG1,LOW);
            digitalWrite(MoteurG2,LOW);
            digitalWrite(PWMG,LOW);
          //PARAMETRE DE INTERUPTEUR
  // Initialisation du bouton en entrée
  
        }
        
void loop() {
   // Lecture de l'état du bouton
            servoMoteur(88); // ont centre le capteur ultra son au debut du programme  
          delay(300);  // on attend
    //       fonction_automatique();// on passe en mode automatique
   bluetooth();// ont appelle la fonction bluetooth pour commande le robot manuellement
    
}              

         // fonction permetant de recuperé la distance messurer par le capteur ultra son
        long Mesure_distance(){
        long   temps=0;// variable du temps
          long distance=0;// variable pour contenir la distance
          digitalWrite(trig,HIGH);//on met le trig a l'etat haut
          delayMicroseconds(10);// on attend 20 microseconde
          digitalWrite(trig,LOW);// on met le trip du capteur a l'etat bas
          temps=pulseIn(echo,HIGH);// pour calculer le temps d'emissin du son et reception du son par le capteur utra son
          distance=temps/58; //pour calculer la distance mesurer en cm
          Serial.print("distance: ");// on affiche '' distance: '' sur le moniteur serie
          Serial.println(distance);// on affiche la distance

          delay(100);//on attend
         return(distance);// on retourne la distance a la fin
         }
         
         
         // fonction permettant de faire tourne le cerveau moteur d'un angle donné
         void servoMoteur(int angle) { // fonction pour faire tourne le servo moteur
           
    cerv.write(angle); //pour faire tourne le cerveau moteur d'un angle angle
    }
    
    void fonction_rotation_cerveau(){ // fonction qui premet au robot d'interagir avec son environnement
                bluetooth();
         long a=0;// a n'est pas une variable
       tone(buzzer,650,10000); // Send 1KHz sound signal...
        //  rotation a droite du capteur ultra-son et fonction a executer
       
          servoMoteur(30);// on effectue une rotation a droite
              
                    delay(500);// pour une pause
      
                     a=Mesure();// on effectue 5 prise pour avoir une bonne mesure
         
                if(a>50){// dans le cas ou il y a pas de choc
                    noTone(buzzer);    // buzzer stop
                    fonction_Droite();//le robot tourne a droite
                    delay(700);//on attend 
                    fonction_stop();//le robot s'arrete
                    delay(500);//on attend
                    servoMoteur(88);// pour placer le capteur le capteur ultra son a la position avance
                    delay(500);// on atteend
                    
                            while(a>50){  //tant que la distance est superieur a 50 alors
                                 noTone(buzzer);// le buzzer s'arrete      
                                fonction_avance();// on avance
                               a=Mesure();// pour evite de tourné indéfinement dans la boucle 
                               
                                }
                                 
                                 fonction_stop();// le robot s'arrete
                         delay(500);// on attend
                                }
                                 tone(buzzer,650,10000); // le buzzer emet une alerte
            servoMoteur(88);// on place le capteur ultra son au centre     
            
     delay(500);// on attend
        servoMoteur(150);// on tourne le capteur ultra son a gauche pour mesure la distance
      delay(500);// on attend
                          
                     
               // on effectue une rotation a gauche car la mesure est inférieur au seuil alors on deplace le capteur ultra son de la droite vers la gauche             
                         
                          // test de l'etat gauche apres une rotation
              
                     a=Mesure();// on effectue 5 prise pour avoir une bonne mesure
                if(a>50){ // dans le cas ou il y a pas d'obstacle a gauche
                    noTone(buzzer);    // Stop sound...
                    fonction_gauche();// le robot tourne a gauche
                   delay(700);// on attend
                    fonction_stop();// le robot s'arrete
                           delay(300);// on attend
                    servoMoteur(88);// centriliser le capteur ultra song avant d'avance
                    delay(300);// on attend
    
                            while(a>40){
                                  noTone(buzzer);    // on stop le son du buzzer     
                                fonction_avance();//on avance tant que a>40
                                 // pour evite de caller dans la boucle 
                                 a=Mesure();
                                }
                                
                                fonction_stop(); 
                              
                            }
                          
                         }
                        
                        
                        
          long Mesure(){// pour faire 1 mesure avant de prendre une décission.modifiable si necssaire
             int i;
             long a=0;
           
               for(i=0;i<=1 ;i++){
                    a= Mesure_distance();
                      i++;
                  }
                  return(a);
                  }
  void fonction_gauche()// fonction pour dire au robot TOURNE A GAUCHE
{
  
digitalWrite(MoteurD2,HIGH);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,HIGH);
digitalWrite(PWMG,100);

}
void fonction_Droite()// fonction pour dire au robot de TOURNE A DROITE
{    
 
    
digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,HIGH);//
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,HIGH);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100);

}
void fonction_arriere()// fonction pour dire au robot de RENTRER
{

digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,HIGH);
digitalWrite(PWMD,110);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,HIGH);
digitalWrite(PWMG,110);
}
void fonction_avance()// fonction pour dire au robot de AVANCE
{
digitalWrite(MoteurD2,HIGH);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,100);
digitalWrite(MoteurG2,HIGH);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,100);
}
void fonction_stop()  // fonction pour dire au robot de s'ARRETE
{   
digitalWrite(MoteurD2,LOW);
digitalWrite(MoteurD1,LOW);
digitalWrite(PWMD,0);
digitalWrite(MoteurG2,LOW);
digitalWrite(MoteurG1,LOW);
digitalWrite(PWMG,0);
}

            void fonction_automatique(){
                              
          
            distance=Mesure();// on recupere la valeur mesure apres 3 opérations de mesures
            if(distance>50){
            while(distance>50){
             noTone( buzzer);
                      fonction_avance(); 
                      distance=Mesure(); //on fait des mesures pour eviter de tourner idéfinement dans la boucle
                      }
                        fonction_stop();
            }
             fonction_stop();
             delay(500);
            fonction_arriere();
            delay(500);
            fonction_stop();
             delay(300);
         fonction_rotation_cerveau();

    }             

  long a=0;  // variable qui va stocke la distance mesure 
    void bluetooth(){//parametre de la commande manuele pas bluetooth
 //Read data from HC06
  while(hc06.available()>0){
    cmd+=(char)hc06.read();
  }

  //Select function with cmd
  
    if(cmd=="A"){
             a=Mesure();// on mesure la distance 
             if(a<50){ // si la distance est inferieur a 50cm alors 
             
             
                 fonction_stop(); // on n'avance pas
                 tone(buzzer,650,10000); //le buzzer emet une alerte
               
                    } 
             if(a>=50)// si la distance est superieur ou egal a 50cm alors 
             {
                  noTone(buzzer);// le buzzer n'emet pas d'alerte
                 fonction_avance();// on avance
                 
                
         }
       }  
    else if(cmd=="B"){
      fonction_arriere();// on rentre
delay(2000);// pendant 2 seconde
  fonction_stop();
  Serial.print(cmd); 
    }  
     else if(cmd=="C"){
Serial.print(cmd);
fonction_gauche();// on tourne a gauche
     }
       else if(cmd=="D"){
Serial.print(cmd);
 fonction_Droite();// on tourne a droite

     }
     else if(cmd=="E"){
Serial.print(cmd);
  fonction_stop();// on s'arrete
     }
      else if(cmd=="T"){
Serial.println(cmd);
delay(300);
fonction_automatique();// on passe en mode automatiqu
     }
       else if(cmd=="S"){
        //Serial.print(t);
//Serial.println("arol");
bluetooth();// On passe en mode commande manuel 

     }
     
   
   }
